package com.linkedin.linkedinclone.enumerations;

public enum NotificationType {
    COMMENT,
    INTEREST,
    CONNECTION_REQUEST
}
