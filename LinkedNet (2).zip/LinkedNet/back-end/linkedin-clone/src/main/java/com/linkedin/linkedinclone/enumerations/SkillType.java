package com.linkedin.linkedinclone.enumerations;

public enum SkillType {
    EDUCATION,
    SKILL,
    EXPERIENCE
}
