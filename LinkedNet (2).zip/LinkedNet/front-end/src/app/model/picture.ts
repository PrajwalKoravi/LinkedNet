export class Picture {
    id: number;  
    name: string;
    type: string;
    bytes: any;
  }