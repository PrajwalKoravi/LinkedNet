import { User } from "./user";

export class SkillsAndExperience{
    type: string;
    description: string;
    isPublic: number;
}